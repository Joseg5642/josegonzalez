<div class="wrap">
		<div id="lbg_logo">
			<h2>Overview</h2>
		</div>
		<div class="postbox-container" style="width:100%">
			<div class="postbox">
				<h3 style="padding:7px 10px;"><strong>Sticky Radio Player - Full Width Shoutcast and Icecast HTML5 Player</strong></h3>
				<div class="inside">		
				<p>This plugin will allow you to insert an advanced Sticky HTML5 Radio Player With Playlist, Categories and Search</p>
				<p>You have available the following sections:</p> 
				<ul class="lbg_list-1">
					<li><a href="?page=LBG_AUDIO5_HTML5_SHOUTCAST_Manage_Players">Manage Players</a></li>
					<li><a href="?page=LBG_AUDIO5_HTML5_SHOUTCAST_Add_New">Add New</a> (player)</li>
					<li><a href="?page=LBG_AUDIO5_HTML5_SHOUTCAST_Manage_Categories">Manage Categories</a>
		          <li><a href="?page=LBG_AUDIO5_HTML5_SHOUTCAST_Help">Help</a></li> 
				</ul>
			  </div>
			</div>	
		</div>
	</div>